@extends('layouts.userLayout')

@section('content')
<div class="container">
    <a class="btn btn-secondary" href="/">Go Back</a>
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Register') }}</div>

                <div class="card-body">
                    <form method="POST" action="{{ route('register') }}">
                        @csrf

                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right">{{ __('Name') }}</label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control @error('name') is-invalid @enderror" name="name" value="{{ old('name') }}" required autocomplete="name" autofocus>

                                @error('name')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right">{{ __('E-Mail Address') }}</label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email">

                                @error('email')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password" class="col-md-4 col-form-label text-md-right">{{ __('Password') }}</label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" required autocomplete="new-password">

                                @error('password')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password-confirm" class="col-md-4 col-form-label text-md-right">{{ __('Confirm Password') }}</label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                            </div>
                        </div>
                        <div class="form-group row">
                        <label for="username" class="col-md-4 col-form-label text-md-right">User Name</label>
                        <div class="col-md-6">
                        <input type="text" name="username" class="form-control" id="username">
                        <span class="text-danger error-text address_err"></span>
                        </div>
                    </div>
                        <div class="form-group row">
                        <label for="birth_date"  class="col-md-4 col-form-label text-md-right" >Birth Date</label>
                        <div class="col-md-6">
                        <input type="date" name="birth_date" class="form-control" id="birth_date">
                        </div>
                        </div>
                        <div class="form-group row">
                        <label for="country" class="col-md-4 col-form-label text-md-right">Place</label>
                        <div class="col-md-6">
                        <input type="text" name="country" class="form-control" id="country">
                        </div>
                    </div>
                    <div class="form-group row">
                                <label class="col-md-4 col-form-label text-md-right"><strong>Select Category :</strong></label><br/>
                                <div class="col-md-6">
                                <select class="form-control" name="cat[]" multiple="multiple">
                                  <option value="english">English</option>
                                  <option value="malayalam">Malayalam</option>
                                  <option value="hindi">Hinde</option>
                                  
                                </select>
</div>

                            </div>
                          

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    {{ __('Register') }}
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script type="text/javascript">

$.ajaxSetup({
  headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
  }
});

        $(document).ready(function() {
            $("#username").change(function(){
                // var _token = $("input[name='_token']").val();
                var username = $("#username").val();
                $.ajax({
                    url: "/register/uniqueCheck",
                    type:'GET',
                    data: {"_token": "{{ csrf_token() }}","username":username},
                    // headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                    success: function(data) {
                        console.data
                    console.log(data.status)
                        if(data.status == 0){
                            $('.address_err').text(data.message);
                        }
                        else{
                            $('.address_err').text('');
                        }
                    }
                });
            }); 
        });
    </script>
@endsection
