@extends('layouts.userLayout')

@section('content')
<div class="container">
        <h3 class="text-center">Edit User</h3>
    <div class="row">
        <div class="offset-md-3 col-md-6">
            <form method="POST" action={{url('profile/')}} enctype="multipart/form-data">
                @csrf
                <div class="form-group">
                    <label for="full_name">Full Name</label>
                    <input type="text" name="name" class="form-control @error('name') is-invalid @enderror" id="full_name" value='{{$user->name}}'>
                    @error('name')
                        <div class="invalid-feedback">
                                {{ $message }}
                        </div>
                    @enderror
                </div>
                <div class="form-group">
                    <label for="email">Email address</label>
                    <input type="email" name="email" class="form-control @error('email') is-invalid @enderror" id="email" value='{{$user->email}}'>
                    @error('email')
                        <div class="invalid-feedback">
                                {{ $message }}
                        </div>
                    @enderror
                </div>
                <div class="form-group">
                    <label for="birth_date">Birth Date</label>
                    <input type="date" name="birth_date" class="form-control" id="birth_date" value='{{$user->dob}}'>
                </div>
                <div class="form-group">
                    <label for="country">Location</label>
                    <input type="text" name="country" class="form-control" id="country" value='{{$user->location}}'>
                </div>   
                <div class="form-group">
                    <label for="mobile">Mobile</label>
                    <input type="text" name="mobile" class="form-control" id="mobile" value='{{$user->mobile}}'>
                </div>   
                <div class="form-group ">
                                <label><strong>Select Category :</strong></label><br/>
                               
                                <select class="form-control" name="cat[]" multiple="multiple">
                                  <option value="php">PHP</option>
                                  <option value="react">React</option>
                                  <option value="jquery">JQuery</option>
                                  <option value="javascript">Javascript</option>
                                  <option value="angular">Angular</option>
                                  <option value="vue">Vue</option>
                                </select>
                            </div>
                    <div class="form-group ">
                        <label for="username" >User Name</label>
                      
                        <input type="text" name="username" class="form-control" id="username" value='{{$user->user_name}}'>
                        </div>
                <!-- <div class="form-group">
                    <div class="custom-file">    
                        <input type="file" class="custom-file-input" id="image" name="image">
                        <label class="custom-file-label" for="image">Upload New Image</label>
                    </div>
                </div> -->
                <input type="hidden" name="_method" value="PUT">
                <button type="submit" class="btn btn-primary btn-block">Update</button>
            </form>
        </div>
    </div>
</div>
@endsection