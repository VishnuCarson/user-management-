@extends('layouts.userLayout')

@section('content')
<div class="container">
    <a class="btn btn-secondary" href="/home">Go Back</a>
    <h3 class="text-center">{{$user->name}}</h3>
    <div class="row">
        <div class="offset-md-2 col-md-8 mt-3 user-info">
            <div class="text-center mb-4">
                <img class="profile_image text-center" src="{{($user->image == NULL) ? '/img/no-photo.png' : '/storage/' . $user->image }}" alt="image">
               
            </div>
            <p><strong>Name: </strong> {{$user->name}}</p>
            <p><strong>UserName: </strong> {{$user->user_name}}</p>
            <p><strong>Email: </strong> {{$user->email}}</p> 
            <p><strong>Birth Date: </strong> {{$user->dob}}</p> 
            <p><strong>Location: </strong> {{$user->location}}</p> 
            <?php 
            $healthy = [']', '[', '"'];
            $yummy   = ['', '', ''];
            ?>
            <p><strong>Language: </strong> {{str_replace($healthy, $yummy,$user->language)}}</p>

            <a href="/profile/edit" class="btn btn-primary">Edit Profile</a>
            <a href={{"/profile/changePassword"}} class="btn btn-primary">change Password</a>
        </div>
    </div>
</div>
@endsection