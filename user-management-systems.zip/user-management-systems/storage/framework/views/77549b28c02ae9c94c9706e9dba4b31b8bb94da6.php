<?php $__env->startSection('content'); ?>
<div class="container">
    <a class="btn btn-secondary" href="/home">Go Back</a>
    <h3 class="text-center"><?php echo e($user->name); ?></h3>
    <div class="row">
        <div class="offset-md-2 col-md-8 mt-3 user-info">
            <div class="text-center mb-4">
                <img class="profile_image text-center" src="<?php echo e(($user->image == NULL) ? '/img/no-photo.png' : '/storage/' . $user->image); ?>" alt="image">
               
            </div>
            <p><strong>Name: </strong> <?php echo e($user->name); ?></p>
            <p><strong>UserName: </strong> <?php echo e($user->user_name); ?></p>
            <p><strong>Email: </strong> <?php echo e($user->email); ?></p> 
            <p><strong>Birth Date: </strong> <?php echo e($user->dob); ?></p> 
            <p><strong>Location: </strong> <?php echo e($user->location); ?></p> 
            <?php 
            $healthy = [']', '[', '"'];
            $yummy   = ['', '', ''];
            ?>
            <p><strong>Language: </strong> <?php echo e(str_replace($healthy, $yummy,$user->language)); ?></p>

            <a href="/profile/edit" class="btn btn-primary">Edit Profile</a>
            <a href=<?php echo e("/profile/changePassword"); ?> class="btn btn-primary">change Password</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.userLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\user-management-systems\resources\views/profile/view.blade.php ENDPATH**/ ?>