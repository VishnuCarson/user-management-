<?php $__env->startSection('content'); ?>
<div class="container">
        <h3 class="text-center">Edit User</h3>
    <div class="row">
        <div class="offset-md-3 col-md-6">
            <form method="POST" action=<?php echo e(url('profile/')); ?> enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="full_name">Full Name</label>
                    <input type="text" name="name" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="full_name" value='<?php echo e($user->name); ?>'>
                    <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                        <div class="invalid-feedback">
                                <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <div class="form-group">
                    <label for="email">Email address</label>
                    <input type="email" name="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="email" value='<?php echo e($user->email); ?>'>
                    <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                        <div class="invalid-feedback">
                                <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <div class="form-group">
                    <label for="birth_date">Birth Date</label>
                    <input type="date" name="birth_date" class="form-control" id="birth_date" value='<?php echo e($user->dob); ?>'>
                </div>
                <div class="form-group">
                    <label for="country">Location</label>
                    <input type="text" name="country" class="form-control" id="country" value='<?php echo e($user->location); ?>'>
                </div>   
                <div class="form-group">
                    <label for="mobile">Mobile</label>
                    <input type="text" name="mobile" class="form-control" id="mobile" value='<?php echo e($user->mobile); ?>'>
                </div>   
                <div class="form-group ">
                                <label><strong>Select Category :</strong></label><br/>
                               
                                <select class="form-control" name="cat[]" multiple="multiple">
                                  <option value="php">PHP</option>
                                  <option value="react">React</option>
                                  <option value="jquery">JQuery</option>
                                  <option value="javascript">Javascript</option>
                                  <option value="angular">Angular</option>
                                  <option value="vue">Vue</option>
                                </select>
                            </div>
                    <div class="form-group ">
                        <label for="username" >User Name</label>
                      
                        <input type="text" name="username" class="form-control" id="username" value='<?php echo e($user->user_name); ?>'>
                        </div>
                <!-- <div class="form-group">
                    <div class="custom-file">    
                        <input type="file" class="custom-file-input" id="image" name="image">
                        <label class="custom-file-label" for="image">Upload New Image</label>
                    </div>
                </div> -->
                <input type="hidden" name="_method" value="PUT">
                <button type="submit" class="btn btn-primary btn-block">Update</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.userLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\user-management-systems\resources\views/profile/edit.blade.php ENDPATH**/ ?>