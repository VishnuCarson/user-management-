<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\User;
use Hash;

class ProfileController extends Controller
{
    public function show()
    {
        if(Auth::user()->admin == 0) { 
            $user_id = Auth::user()->id;
            $user = User::find($user_id);
            return view('profile.view', compact('user'));
        }
        else {
            return redirect('/admin-panel');
        }
    }

    
    public function edit()
    {
        if(Auth::user()->admin == 0) { 
            $id = Auth::user()->id;
            $user = User::find($id);
            return view('profile.edit', compact('user'));
        }
        else {
            return redirect('/admin-panel');
        }
    }

    public function changePassword()
    {
        
        return view('profile.changePassword');
    }
    public function updatePassword(Request $request)
{


    $image_path = '';

    if ($request->hasFile('image')) {
        $image_path =  $request->image->store('profile_pics', 'public');
    }

   


    // if($request->hasFile('image')) {
    //     $user->image = $request->image->store('profile_pics', 'public');
    // }
    // print_r("asdf");
    // die();
        # Validation
        $request->validate([
            'old_password' => '',
            'new_password' => 'confirmed',
        ]);


        #Match The Old Password
        // if(!Hash::check($request->old_password, auth()->user()->password)){
        //     return back()->with("error", "Old Password Doesn't match!");
        // }


        #Update the new Password
        User::whereId(auth()->user()->id)->update([
            'password' => Hash::make($request->new_password),
            'image'=> $image_path,
        ]);

        return back()->with("status", "Updated successfully ");
}


    public function update(Request $request)
    {

        $validatedData = $request->validate([
            'name' => 'required:max:40',
            'email' => 'required|max:190',
            'password' => 'nullable|min:8|confirmed',
        ]);

        if(Auth::user()->admin == 0) { 
            $id = Auth::user()->id;
            $user = User::find($id);
            $user->name = $request->name;
            $user->email = $request->email;
            $user->dob = $request->birth_date; 
            $user->location = $request->country;
            $user->mobile = $request->mobile;
            $user->user_name = $request->username;
            $user->language = json_encode($request->cat);
            // if($request->hasFile('image')) {
            //     $user->image = $request->image->store('profile_pics', 'public');
            // }
            $user->save();

            return redirect('/home')->with('msg_success', 'Your Profile is Updated');
        }
        else {
            return redirect('/admin-panel');
        }
    }

    
}
